// ==========================================
// 🔒 SYSTEM AUTH GUARD (ระบบตรวจสอบการล็อกอิน)
// ==========================================
document.addEventListener('DOMContentLoaded', async () => {
    // 1. ตรวจสอบว่าหน้าที่เปิดอยู่ ใช่หน้า Login หรือ Register หรือไม่ (ถ้าใช่ ให้ข้ามการเช็คไป)
    const currentPath = window.location.pathname;
    if (currentPath.includes('login.html') || currentPath.includes('register.html')) {
        return; 
    }

    // 2. ถ้าเป็นหน้าจอระบบ ให้วิ่งไปถาม Backend ว่ามี Session หรือไม่
    try {
        const res = await fetch('api/check_auth.php');
        const data = await res.json();
        
        if (!data.auth) {
            // ❌ ยังไม่ล็อกอิน หรือ Session หมดอายุ -> เตะกลับหน้า Login ทันที
            window.location.replace('login.html');
        } else {
            // ✅ ล็อกอินแล้ว -> อัปเดตชื่อผู้ใช้ที่ Sidebar
            const adminNameElements = document.querySelectorAll('.admin-name-display');
            adminNameElements.forEach(el => el.innerText = data.user);
        }
    } catch (error) {
        // กรณีเชื่อมต่อ Server ไม่ได้ ป้องกันไว้ก่อนโดยการเตะออก
        console.error("Auth check failed:", error);
        window.location.replace('login.html');
    }
});

// ==========================================
// 🚪 LOGOUT FUNCTION (ระบบออกจากระบบ)
// ==========================================
window.handleLogout = async function() {
    if(confirm('คุณต้องการออกจากระบบใช่หรือไม่?')) {
        try {
            await fetch('api/logout.php'); // เรียก API เพื่อทำลาย Session
            window.location.replace('login.html');
        } catch (e) {
            console.error('Logout error', e);
        }
    }
}
class DataManager {
    constructor() {
        // ไม่ต้อง init ข้อมูลจำลองแล้ว เพราะข้อมูลอยู่ใน MySQL
    }

    // --- Members ---
    async getMembers() {
        try {
            // เรียกไฟล์ PHP
            const response = await fetch('api/members.php');
            return await response.json();
        } catch (error) {
            console.error('Error:', error);
            return [];
        }
    }

    async addMember(member) {
        await fetch('api/members.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(member)
        });
    }

    async updateMember(member) {
        // ใช้ logic เดียวกับ addMember เพราะใน PHP เขียนดักไว้แล้ว
        await this.addMember(member);
    }

    async deleteMember(id) {
        await fetch(`api/members.php?id=${id}`, {
            method: 'DELETE'
        });
    }

    // --- Devices ---
    async getDevices() {
        try {
            const response = await fetch('api/devices.php');
            return await response.json();
        } catch (error) {
            return [];
        }
    }

    async addDevice(device) {
        await fetch('api/devices.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(device)
        });
    }

    // (ส่วน Notification กับ SOS ทำหลักการเดียวกัน สร้างไฟล์ php เพิ่ม)
    getNotifications() { return []; }
}

const db = new DataManager();

// ... (ส่วน Sidebar code คงเดิม) ...