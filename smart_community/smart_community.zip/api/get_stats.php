<?php
header("Content-Type: application/json");
header("Cache-Control: no-cache, no-store, must-revalidate");
require '../db_config.php';

// ---------------------------------------------------
// 1. เตะอุปกรณ์ที่ขาดการติดต่อเกิน 3 นาทีให้เป็น Offline
// (ใช้คำสั่งของ MySQL ล้วนๆ เพื่อแก้ปัญหา Timezone เพี้ยน)
// ---------------------------------------------------
$conn->query("UPDATE devices SET status = 'Offline' WHERE last_seen < (NOW() - INTERVAL 3 MINUTE)");

// ---------------------------------------------------
// 2. นับจำนวน Online 
// (นับรวมทั้งหมดในตาราง devices ที่สถานะเป็น Online ซึ่งจะรวม GATEWAY-MAIN ด้วย)
// ---------------------------------------------------
$online_count = 0;
$res_online = $conn->query("SELECT COUNT(*) as count FROM devices WHERE status = 'Online'");
if ($res_online) $online_count = $res_online->fetch_assoc()['count'];

// ---------------------------------------------------
// 3. นับจำนวน SOS
// ---------------------------------------------------
$sos_count = 0;
$res_sos = $conn->query("SELECT COUNT(*) as count FROM alerts WHERE type = 'SOS' AND status != 'resolved'");
if ($res_sos) $sos_count = $res_sos->fetch_assoc()['count'];

// ---------------------------------------------------
// 4. ดึงประกาศล่าสุด
// ---------------------------------------------------
$latest_msg = "ไม่มีประกาศ";
$latest_type = "normal";
$res_last = $conn->query("SELECT * FROM alerts ORDER BY time DESC LIMIT 1");
if ($res_last && $res_last->num_rows > 0) {
    $row = $res_last->fetch_assoc();
    $latest_msg = $row['message'];
    $latest_type = $row['type'];
}

// ---------------------------------------------------
// 5. เช็คสถานะ Gateway ว่า Online หรือไม่
// ---------------------------------------------------
$gateway_status = 'offline';
$res_gw = $conn->query("SELECT status FROM devices WHERE id = 'GATEWAY-MAIN'");
if ($res_gw && $res_gw->num_rows > 0) {
    if ($res_gw->fetch_assoc()['status'] === 'Online') {
        $gateway_status = 'online';
    }
}

// ส่งค่ากลับไปที่หน้า Dashboard
echo json_encode([
    "online" => $online_count,
    "sos" => $sos_count,
    "latest_msg" => $latest_msg,
    "latest_type" => $latest_type,
    "gateway_status" => $gateway_status
]);

$conn->close();
?>