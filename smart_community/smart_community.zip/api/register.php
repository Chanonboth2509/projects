<?php
header("Content-Type: application/json; charset=UTF-8");
include 'db_config.php';

$data = json_decode(file_get_contents("php://input"), true);
$user = $data['username']; // รับชื่อ-นามสกุลมาเป็น username
$email = $data['email'];   // รับอีเมลมา (แม้จะไม่ได้เซฟลงฐานข้อมูลก็รับมาเช็คได้)
$pass = $data['password'];

if (!empty($user) && !empty($pass)) {
    $user = $conn->real_escape_string($user);
    $pass = $conn->real_escape_string($pass);

    // เช็คว่าชื่อผู้ใช้นี้ซ้ำไหม
    $check = "SELECT id FROM admins WHERE username = '$user'";
    if ($conn->query($check)->num_rows > 0) {
        echo json_encode(["status" => "error", "message" => "ชื่อผู้ใช้นี้ถูกใช้ไปแล้ว กรุณาใช้ชื่ออื่น"]);
    } else {
        // บันทึกลงตาราง admins (ไม่ใส่อีเมลเพราะในตารางคุณไม่มีคอลัมน์ email)
        // เอา $user ไปใส่ทั้งในช่อง username และ name
        $sql = "INSERT INTO admins (username, password, name, created_at) 
                VALUES ('$user', '$pass', '$user', NOW())";
        
        if ($conn->query($sql)) {
            echo json_encode(["status" => "success"]);
        } else {
            echo json_encode(["status" => "error", "message" => "SQL Error: " . $conn->error]);
        }
    }
} else {
    echo json_encode(["status" => "error", "message" => "กรุณากรอกข้อมูลให้ครบถ้วน"]);
}
$conn->close();
?>